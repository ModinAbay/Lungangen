//
//  LoginViewController.swift
//  Plant
//
//  Created by MODIN ABAY on 09.06.2022.
//

import Foundation
import UIKit

class LoginViewController: BaseViewController {
    
    var firstImage: UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "seconPage")
        return img
    }()
    
    var loginLabel: UILabel = {
        let lb = UILabel()
        lb.text = "Login"
        lb.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        lb.font = lb.font.withSize(54)
        return lb
    }()
    
    var secondLabel: UILabel = {
        let lbsec = UILabel()
        lbsec.text = "Login your Plantito/Plantita account"
        lbsec.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        lbsec.font = lbsec.font.withSize(12)
        return lbsec
    }()
    
    lazy var firstStacView: UIStackView = {
        let svone = UIStackView(arrangedSubviews: [
        loginLabel,
        secondLabel
        ])
        svone.spacing = 1
        svone.axis = .vertical
        return svone
    }()
    
    var emailadressTextFielt: UITextField = {
        let tf = UITextField()
        tf.text = "Email Adress"
        tf.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        tf.layer.cornerRadius = 10
        tf.backgroundColor = UIColor(red: 0.922, green: 0.992, blue: 0.949, alpha: 1)
        tf.dropShadow()
        let findTextFieldImageView = UIImageView(frame: CGRect(x: 8.0, y: 12.0, width: 20.0, height: 20.0))
        let image = UIImage(named: "mail-bulk")
        findTextFieldImageView.image = image
        let findTextFieldView = UIView(frame: CGRect(x: 0, y: 0, width: 38, height: 40))
        findTextFieldView.addSubview(findTextFieldImageView)
        tf.leftViewMode = UITextField.ViewMode.always
        tf.leftView = findTextFieldView
        return tf
    }()
    
    var passwordTextField: UITextField = {
        let tf = UITextField()
        tf.text = "Password"
        tf.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        tf.layer.cornerRadius = 10
        tf.backgroundColor = UIColor(red: 0.922, green: 0.992, blue: 0.949, alpha: 1)
        tf.dropShadow()
        let findTextFieldImageView = UIImageView(frame: CGRect(x: 8.0, y: 12.0, width: 20.0, height: 20.0))
        let image = UIImage(named: "lock")
        findTextFieldImageView.image = image
        let findTextFieldView = UIView(frame: CGRect(x: 0, y: 0, width: 38, height: 40))
        findTextFieldView.addSubview(findTextFieldImageView)
        tf.leftViewMode = UITextField.ViewMode.always
        tf.leftView = findTextFieldView
        return tf
    }()
    
    var loginButton: UIButton = {
        let btn = UIButton()
        btn.layer.cornerRadius = 10
        btn.backgroundColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        btn.setTitle("Login", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.textAlignment = .center
        btn.dropShadow()
        btn.addTarget(self, action: #selector(PushHomeVC), for: .touchUpInside)
        return btn
    }()
    
    @objc func PushHomeVC() {
        let vc = TabbarViewController()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    var usinshiLabel: UILabel = {
        let lb = UILabel()
        lb.text = "Don’t have an account?"
        lb.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        lb.font = lb.font.withSize(14)
        return lb
    }()
    
    var tortinshiLabel: UILabel = {
        let lb = UILabel()
        lb.text = "Sign up"
        lb.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        lb.font = lb.font.withSize(14)
        return lb
    }()
    
    lazy var secondStackView: UIStackView = {
        let sv = UIStackView(arrangedSubviews: [
        usinshiLabel,
        tortinshiLabel
        ])
        sv.spacing = 4
        sv.axis = .horizontal
        return sv
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
}

extension LoginViewController: ConfigureUI {
    func setupUI() {
        [firstImage, firstStacView, emailadressTextFielt, passwordTextField, loginButton, secondStackView].forEach {
            view.addSubview($0)
        }
        firstImage.snp.makeConstraints {
            $0.top.equalToSuperview()
            $0.leading.trailing.equalToSuperview()
        }
        firstStacView.snp.makeConstraints {
            $0.top.equalTo(firstImage.safeAreaLayoutGuide.snp.bottom).inset(-5)
            $0.leading.equalToSuperview().inset(25)
        }
        emailadressTextFielt.snp.makeConstraints {
            $0.top.equalTo(firstStacView.safeAreaLayoutGuide.snp.bottom).inset(-73)
            $0.leading.equalToSuperview().inset(25)
            $0.height.equalTo(50)
            $0.width.equalTo(325)
        }
        passwordTextField.snp.makeConstraints {
            $0.top.equalTo(emailadressTextFielt.safeAreaLayoutGuide.snp.bottom).inset(-17)
            $0.leading.equalToSuperview().inset(25)
            $0.height.equalTo(50)
            $0.width.equalTo(325)
        }
        loginButton.snp.makeConstraints {
            $0.top.equalTo(passwordTextField.safeAreaLayoutGuide.snp.bottom).inset(-74)
            $0.leading.equalToSuperview().inset(25)
            $0.width.equalTo(325)
            $0.height.equalTo(50)
        }
        secondStackView.snp.makeConstraints {
            $0.top.equalTo(loginButton.safeAreaLayoutGuide.snp.bottom).inset(-9)
            $0.centerX.equalToSuperview()
        }
    }
    
    func configureUI() {
    }
}

