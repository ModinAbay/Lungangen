//
//  HomeViewController.swift
//  Plant
//
//  Created by MODIN ABAY on 09.06.2022.
//

import Foundation
import UIKit

class TabbarViewController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTabBar()
        view.backgroundColor = .white
    }


func configureTabBar() {
    let homeViewControler = HomeViewController()
    let heratViewController = HeartViewController()
    let treeViewController = TreeViewController()
    let vectorViewController = VectorViewController()
    tabBar.backgroundColor = UIColor(red: 0.136, green: 0.412, blue: 0.246, alpha: 0.72)
    tabBar.frame = CGRect(x: 0, y: 0, width: 375, height: 58)
    tabBar.layer.cornerRadius = 48
    modalPresentationStyle = .fullScreen
    modalTransitionStyle = .crossDissolve
    
    [homeViewControler, heratViewController, treeViewController, vectorViewController].forEach {
        $0.navigationController?.navigationBar.isHidden = true
}
    homeViewControler.tabBarItem = UITabBarItem(title: nil, image: UIImage(named: "home")?.withTintColor(.systemGreen).withRenderingMode(.alwaysOriginal), selectedImage: UIImage(named: "home")?.withTintColor(.darkGray).withRenderingMode(.alwaysOriginal))
    
    heratViewController.tabBarItem = UITabBarItem(title: nil, image: UIImage(named: "heart")?.withTintColor(.systemGreen).withRenderingMode(.alwaysOriginal), selectedImage: UIImage(named: "heart")?.withTintColor(.darkGray).withRenderingMode(.alwaysOriginal))
    
   treeViewController.tabBarItem = UITabBarItem(title: nil, image: UIImage(named: "tree")?.withTintColor(.systemGreen).withRenderingMode(.alwaysOriginal), selectedImage: UIImage(named: "tree")?.withTintColor(.darkGray).withRenderingMode(.alwaysOriginal))
    
    vectorViewController.tabBarItem = UITabBarItem(title: nil, image: UIImage(named: "Vector")?.withTintColor(.systemGreen).withRenderingMode(.alwaysOriginal), selectedImage: UIImage(named: "Vector")?.withTintColor(.darkGray).withRenderingMode(.alwaysOriginal))
    
    viewControllers = [
        homeViewControler,
        heratViewController,
        treeViewController,
        vectorViewController
    ]
}
}
