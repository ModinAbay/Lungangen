//
//  BaaseViewController.swift
//  Plant
//
//  Created by MODIN ABAY on 26.05.2022.
//

import Foundation
import SnapKit
import UIKit

protocol ConfigureUI {
    func setupUI()
    func configureUI()
}

class BaseViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
    }
}
