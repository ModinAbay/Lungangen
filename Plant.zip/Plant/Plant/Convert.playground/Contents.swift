import UIKit

// Конвертация - это перевод из одного типа данных или коллекции в другой
// Вы можете конвертировать, как типы данных, так и коллекции
// Не все типы данных, можно между собой конвертировать
// Словарь не возможно переконвертировать - не совместим с другими коллекциями

// Как записать конвертацию
// 1 тип данных или коллекция в которую необходимо переконвертировать Int, String, Array
// 2 () скобки Int(), Float(), Double() ...
// 3 Что нужно переконвертировать Int(20.2), Float(100), String(100)
//


print("to Int============")
print(Int(100))
print(Int(1.2))
let fl1: Float = 12.56
print(Int(fl1))

// True = 1
// False = 0
print(Int(truncating: true))

// ?? Оператор заменяющий nil
print(Int("200") ?? -1)

print(Int("12.1") ?? -1)

print(Int(Float("10.23") ?? 0.0))

let ch1: Character = "8"
// Character не совместим(нельзя конвертировать) ни с одним типом данных, кроме String
//print(Int(ch1) ?? -1)

// Пробелы, спец символы - нельзя применять при конвертиации из строки
print(Int("220 "))

print("to Float=================")
print(Float(1.2))
print(Float(fl1))
print(Float(100))
// True = 1.0
// False = 0.0
print(Float(truncating: true))

// Float, Double - можно конвертировать в строке, как целые числа, так и с точкой
print(Float("100") ?? -1)
print(Float("11.34") ?? -1)


print("to Bool=========")
print(Bool(10))
print(Bool(1.2))
print(Bool(0))
print(Bool(0.0))
print(Bool(8))

// String НЕЛЬЗЯ переконвертировать в Bool
print(Bool("Hi"))


// Таким образом можно переконвертировать - любое значение(число) используя константу или переменную
let myNumbs: NSNumber = 12
print(Bool(truncating: myNumbs))

// print(Bool(truncating: fl1))


print("to String ==============")
// String - универсальный тип данных, в который можно переконвертировать любой другой тип данных
print(String(10))
print(String(fl1))
print(String(125.67))
print(String(true))
print(String(false))
print(String(ch1))
print(String("Hello"))

// Коллекции и типы данных, между собой НЕ СОВМЕСТИМЫ
let arr = [10, 20, 30]
//print(String(arr))

// Интерполяция строки - вставка объекта в строку \()
print("\(arr)")

print("to Character =====")
print(String(ch1))

// Character with String
print(Character("Q"))
print(String("Q"))
print(Bool("Q"))













let val = "20"
let convToInt = Int(val)
print(2022 - (convToInt ?? 0)) // ?? Это оператор заменяющий nil, используется для обработки опциональных переменных или констант


// Коллекции, можно конвертировать только в коллекции, а типы данных - только в типы данных
// Словарь - не совместим ни с одной коллекцией!
// Вы можете конвертировать Set в Array или на оборот
var myArray = [100, 20, 30, 100, 200, 20, 30, 90, 80, 50, 20]
// Массив уже не будет из уникальных элементов
var mySet = Set(myArray)

// Конвертируем массив в множество и возврвщвем массив обратно
let backToArray = Array(Set(myArray))

if backToArray.indices.contains(5) {
    backToArray[5]
} else {
    print("Index now tound")
}

// Проверка индекса, перед чтение значения элемента по указанному индексу
if backToArray.indices.contains(9) {
    backToArray[9]
} else {
    print("Index now tound")
}


// ДЗ
// Создать 6 переменных, с каждым типом данных
// В каждый тип данных (6 типов) - попытаться переконвертировать каждую переменную
// Дописать работу с print("to Double =============")
//

var police = 101
print(104 - police)

print(Bool(truncating: 0.00033332))

print(Character("A"))


let double: NSNumber = 10.100000000000000
print(Int(truncating: double))
print(Float(truncating: double))
print(Bool(truncating: double))
print(Int(truncating: double))

//HomeWork
let old = "10"
print(String(10))

let first = "0.1"
print(Float(0.1))

var havemoney = "20.0000002222"
havemoney = "0.0000033302221"
let convmoney = Double(havemoney)
print(20.0000033302221 - (convmoney ?? 0.0000033302221))


let mecar: NSNumber = 10
print(Bool(truncating: mecar))


let mynumb: NSNumber = 0.212121
print(Bool(truncating: mynumb))


// HW
print("to Double =============")
// HW
let myGames: NSNumber = 20.000000000000333
print(Double(truncating: myGames))
let myFirstgames: NSNumber = 20.384737343433
print(Double(20.384737343433) - 0.888777774433)



