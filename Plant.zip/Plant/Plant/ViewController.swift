//
//  ViewController.swift
//  Plant
//
//  Created by MODIN ABAY on 26.05.2022.
//

import UIKit

class ViewController: UIViewController {
    
    var image: UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "unsplash")
        return img
    }()
    
    var headLabel: UILabel = {
        let lb = UILabel()
        lb.text = "Register "
        lb.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        lb.font = lb.font.withSize(36)
        return lb
    }()
    
    var secondLabel: UILabel = {
        let lb = UILabel()
        lb.text = "Create an account to be a Certified\n Plantito/Plantita"
        lb.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        lb.font = lb.font.withSize(12)
        return lb
    }()
    
    lazy var firstStacView: UIStackView = {
        let sv = UIStackView(arrangedSubviews: [
        headLabel,
        secondLabel
        ])
        sv.spacing = 5
        sv.axis = .vertical
        return sv
    }()
    
    var fullNameTextField: UITextField = {
        let tf = UITextField()
        tf.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        tf.layer.cornerRadius = 10
        tf.text = "Full Name"
        tf.dropShadow()
        tf.backgroundColor = UIColor(red: 0.922, green: 0.996, blue: 0.949, alpha: 1)
        let findTextFieldImageView = UIImageView(frame: CGRect(x: 8.0, y: 12.0, width: 20.0, height: 20.0))
        let image = UIImage(named: "lock")
        findTextFieldImageView.image = image
        let findTextFieldView = UIView(frame: CGRect(x: 0, y: 0, width: 38, height: 40))
        findTextFieldView.addSubview(findTextFieldImageView)
        tf.leftViewMode = UITextField.ViewMode.always
        tf.leftView = findTextFieldView
        return tf
    }()
    
    var emailAdressTextField: UITextField = {
        let tf = UITextField()
        tf.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        tf.layer.cornerRadius = 10
        tf.text = "Email Address"
        tf.dropShadow()
        tf.backgroundColor = UIColor(red: 0.922, green: 0.996, blue: 0.949, alpha: 1)
        let findTextFieldImageView = UIImageView(frame: CGRect(x: 8.0, y: 12.0, width: 20.0, height: 20.0))
        let image = UIImage(named: "mail-bulk")
        findTextFieldImageView.image = image
        let findTextFieldView = UIView(frame: CGRect(x: 0, y: 0, width: 38, height: 40))
        findTextFieldView.addSubview(findTextFieldImageView)
        tf.leftViewMode = UITextField.ViewMode.always
        tf.leftView = findTextFieldView
        return tf
    }()
    
    var passwordTextField: UITextField = {
        let tf = UITextField()
        tf.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        tf.layer.cornerRadius = 10
        tf.text = "Password"
        tf.dropShadow()
        tf.backgroundColor = UIColor(red: 0.922, green: 0.996, blue: 0.949, alpha: 1)
        let findTextFieldImageView = UIImageView(frame: CGRect(x: 8.0, y: 12.0, width: 20.0, height: 20.0))
        let image = UIImage(named: "lock")
        findTextFieldImageView.image = image
        let findTextFieldView = UIView(frame: CGRect(x: 0, y: 0, width: 38, height: 40))
        findTextFieldView.addSubview(findTextFieldImageView)
        tf.leftViewMode = UITextField.ViewMode.always
        tf.leftView = findTextFieldView
        return tf
    }()
    
    var confirmPasswordTextField: UITextField = {
        let tf = UITextField()
        tf.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        tf.layer.cornerRadius = 10
        tf.text = "Confirm Password"
        tf.dropShadow()
        tf.backgroundColor = UIColor(red: 0.922, green: 0.996, blue: 0.949, alpha: 1)
        let findTextFieldImageView = UIImageView(frame: CGRect(x: 8.0, y: 12.0, width: 20.0, height: 20.0))
        let image = UIImage(named: "lock")
        findTextFieldImageView.image = image
        let findTextFieldView = UIView(frame: CGRect(x: 0, y: 0, width: 38, height: 40))
        findTextFieldView.addSubview(findTextFieldImageView)
        tf.leftViewMode = UITextField.ViewMode.always
        tf.leftView = findTextFieldView
        return tf
    }()
    
    var thirdLabel: UILabel = {
        let lb = UILabel()
        lb.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        lb.text = "By signing, you agree to our terms of use and privacy notice"
        lb.font = lb.font.withSize(16)
        return lb
    }()
    
    var signinButton: UIButton = {
        let btn = UIButton()
        btn.layer.cornerRadius = 10
        btn.backgroundColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        btn.titleLabel?.textColor = .white
        btn.setTitle("Sign In", for: .normal)
        btn.addTarget(self, action: #selector(showsignUPVC), for: .touchUpInside)
        btn.dropShadow()
        return btn
    }()
    
    var fifthLabel: UILabel = {
        let lb = UILabel()
        lb.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        lb.text = "Already have an account?"
        lb.font = lb.font.withSize(16)
        return lb
    }()
    //posmotri
    var loginLabel: UILabel = {
        let lb = UILabel()
        lb.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        lb.text = "Login"
        lb.font = lb.font.withSize(16)
        let tap = UIGestureRecognizer(target: self, action: #selector(ShowLogin))
        lb.isUserInteractionEnabled = true
        lb.addGestureRecognizer(tap)
        return lb
    }()
    
    lazy var lastStackView: UIStackView = {
        let sv = UIStackView(arrangedSubviews: [
        fifthLabel,
        loginLabel
        ])
        sv.spacing = 5
        sv.axis = .horizontal
        return sv
    }()
    
    @objc func showsignUPVC() {
        let vc = LoginViewController()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc fileprivate func ShowLogin() {
        let vc = HomeViewController()
        navigationController?.pushViewController(vc, animated: true)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        // Do any additional setup after loading the view.
    }
}

extension ViewController: ConfigureUI {
    func setupUI() {
        [image, firstStacView, fullNameTextField, emailAdressTextField, passwordTextField, confirmPasswordTextField, thirdLabel, signinButton, lastStackView].forEach {
            view.addSubview($0)
        }
        image.snp.makeConstraints {
            $0.top.equalToSuperview()
            $0.leading.trailing.equalToSuperview()
        }
        firstStacView.snp.makeConstraints {
            $0.top.equalTo(image.safeAreaLayoutGuide.snp.bottom).inset(-10)
            $0.leading.equalToSuperview().inset(25)
        }
        fullNameTextField.snp.makeConstraints {
            $0.top.equalTo(firstStacView.safeAreaLayoutGuide.snp.bottom).inset(-20)
            $0.leading.equalToSuperview().inset(25)
            $0.width.equalTo(325)
            $0.height.equalTo(50)
        }
        emailAdressTextField.snp.makeConstraints {
            $0.top.equalTo(fullNameTextField.safeAreaLayoutGuide.snp.bottom).inset(-10)
            $0.leading.equalToSuperview().inset(25)
            $0.width.equalTo(325)
            $0.height.equalTo(50)
        }
        passwordTextField.snp.makeConstraints {
            $0.top.equalTo(emailAdressTextField.safeAreaLayoutGuide.snp.bottom).inset(-10)
            $0.leading.equalToSuperview().inset(25)
            $0.width.equalTo(325)
            $0.height.equalTo(50)
        }
        confirmPasswordTextField.snp.makeConstraints {
            $0.top.equalTo(passwordTextField.safeAreaLayoutGuide.snp.bottom).inset(-10)
            $0.leading.equalToSuperview().inset(25)
            $0.width.equalTo(325)
            $0.height.equalTo(50)
        }
        thirdLabel.snp.makeConstraints {
            $0.top.equalTo(confirmPasswordTextField.safeAreaLayoutGuide.snp.bottom).inset(-15)
            $0.leading.equalToSuperview().inset(22)
            $0.trailing.equalToSuperview().inset(28)
        }
        signinButton.snp.makeConstraints {
            $0.top.equalTo(thirdLabel.safeAreaLayoutGuide.snp.bottom).inset(-41)
            $0.leading.trailing.equalToSuperview().inset(25)
            $0.width.equalTo(325)
            $0.height.equalTo(50)
        }
        lastStackView.snp.makeConstraints {
            $0.top.equalTo(signinButton.safeAreaLayoutGuide.snp.bottom).inset(-9)
            $0.centerX.equalToSuperview()
        }
    }
    func configureUI() {
    }
}

extension UIView {
    func dropShadow(scale: Bool = true) {
        layer.masksToBounds = false
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.2
        layer.shadowOffset = .init(width: 2, height: 4)
        layer.shadowRadius = 1
        layer.shouldRasterize = true
        layer.rasterizationScale = scale ? UIScreen.main.scale : 5
    }
}
