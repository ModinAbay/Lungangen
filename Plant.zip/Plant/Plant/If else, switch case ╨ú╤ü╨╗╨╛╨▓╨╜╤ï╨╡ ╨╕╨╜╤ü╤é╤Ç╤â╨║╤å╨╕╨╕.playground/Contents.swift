import UIKit
import CoreGraphics
import Darwin

var greeting = "Hello, playground"

// Условная инструкция if, if else, if else if
// Нужна для проверки условий и выполнения кода при определенном условии
// if = true
// else = false
// Всегда, начинается с if
// Может выполнятся, только одно условие за раз, или if, или else


// Как записать?
// 1 if ключевое слово
// 2 первая переменная, с которой будет сравниваться вторая переменная
// 3 условие - любое (==, != <, > ...)
// 4 вторая переменная или значение, с которой будет сравниваться - первая переменная или значение
// 5 {
// 6 Код для выполнения в if
// 7 }
// По необходимости
// 8 else ключевое слово
// 9 {
// 10 код - если условие в if не выполнилось
// 11 }

var i = 100
print("Простая инструкция if ==========")

if i == 10 { // true
    print("Yes")
}

// Не отображается, потому что, условие не верно и Вы получаете false, а в if всегда указывается true
print(i == 10)

i = 10
if i > 10 { // true
    print("i > 10")
}

print("if else=============")
i = 20

if i == 22 { // true
    print("I = 22")
} else { // false
    print("Else i != 22")
}

func check(age: Int) -> String {
    if age >= 18 {
        return "Welcome to the club"
    } else {
        return "Sorry.."
    }
}

print(check(age: 21))


print("Вложенный if =============")
i = 0
var b = 3

if i >= 1 { // true
    print("I >= 1")
    // Вложенный или зависимый if
    if b == 3 { // true
        print("b == 3")
    }
}

// Часто, используют с 2-3вложенностями, не больше
print("Вложенный if else =============")
if i >= 2 { // true
    print("i >= 2")
    
    if b == 4 { // true
        print("b == 4")
    } else {
        print("Else b == 4")
    }
} else {
    print("Else i >= 2")
}

print("Условия для if ========")
// == равно
// != не равно

// > больше
// < меньше

// >= больше или равно
// <= меньше или равно

print("if else if ==============")
i = 22

if i <= 20 { // true
    print("i <= 20")
} else if b == 22 { // true
    print("else if i == 22")
} else { // else
    print("Else, sorry")
}

print("Логические операторы &&, ||")
// При проверке строк, или символов, обращайте внимание на регистр, регистр - есть только у алфавит
// Регистру не поддаются, цифры или спец символы

// Логические операторы, позволяют проверить более одной проверки в одном блоке if
// && - и то и то, все условия, должны возвращать true
var name = "Alex"
var age = 20

if name == "Alex" && age >= 18 {
    print("Happy day, Alex")
} else {
    print("Else &&")
}

print("==================")
// || - или то, или то, минимум одно условие, должно быть true
if name == "Alex" || age >= 18 {
    print("Happy day, Alex")
} else {
    print("Else &&")
}

print("&& ||=============")
// Комбинированная проверка, с использование ||, &&
if (name == "Alex" && age >= 18) || ( b == 4) || ( 2 != 3) || (2 == 2) {
    print("Happy day, Alex")
} else {
    print("Else &&")
}

print("Регистр - нижний и ВЕРХНИЙ ===")
name = "Tom"
var name2 = "MAX"

if name == "Tom" {
    print("Name", name)
} else {
    print("Else name")
}

print("====")
if name == "tom" {
    print("Name", name)
} else {
    print("Else name")
}

print("lowercased(), uppercased() ===========")
"".lowercased() // все буквы - маленькие
"".uppercased() // все буквы - БОЛЬШИЕ

print("большие буквы все 12345 , ...".uppercased())
print("Маленькие БУКвы ВСЕ! 12345 , ...".lowercased())

// Если Вы понижаете слева, то желательно, понизить и справа
// Применяется понижение или повышение, тольки к типам: String и Character
if name.lowercased() == "TOm".lowercased() {
    print("Name", name)
} else {
    print("Else name")
}


// Создать 6 переменных - разных типов, и заполнить их - значениями
// Каждую переменную - проверить, отдельно, используя - каждый пройденный блок в этом файле
// Выучить все условия
// Выучить все конструкции


//if card == card("black")
//print(card)
//} else {
//    print(secondcard("you win"))
//}

// HW
//Простые конструкции
var haveincard = 10000

if haveincard == 20000 {
    print("yes")
} else {
    print("no")
}


func check (money: Int) -> String {
    if money == 20000 {
        return "you should buy"
} else {
    return "you shouldn buy"
}
}

print(check(money: 20000 ))

var cash = 500
var creditcartd = 2000

    if cash >= 700 {
        print("cash >= 500")
    } else if creditcartd == 2000 {
        print("pay for credit card =< 2000")
    } else {
        print("Your choose")
    }


var creditcard = creditcartd
if cash >= 500 && creditcard != 2000 { // true
    print("Buy")
} else { // false
    print("Else &&")
}

if cash >= 500 || creditcard != 2000 {
    print("Buy")
} else {
    print("Else &&")
}


print("SWITCH CASE ============")
// Используется, когда Вы хотите одну переменную, константу или другое значение - проверить на разные значения
// Если Вы используете if, if else, то Вы можете проверить ТОЛЬКО 2 условия

var theFirstName = "Tony"

// В switch case должен быть - минимум один case
// case не может повторяться по условию - значение проверки
switch theFirstName {
case "alex":
    print("Hi, alex")
    print("Ok, alex")
case "Alex":
    print("Alex")
case "Tom":
    print("Hi, Tom")
    
// Этот блок - обязателен!
default:
    print("Soory, we cannot")
}

print("=========")
theFirstName = "ALEX"
switch theFirstName.lowercased() {
case "Alex".lowercased():
    print("Ok, lower")
default:
    break
}

print("===========")
let city = "Almaty"
switch city {
case "1" :
    print("My city")
default:
    print("Life there")
}

print("==========")
func setColor(color: String) -> String {
    switch color.lowercased() {
    case "red":
        return "Your color is red"
    case "black":
        return "Your color is black"
    default:
        return "another color ..."
    }
}


print(setColor(color: "rEd"))

print("===========")
// В switch case выполняется только один case
// После выполнения case - из switch case будет выход
// В switch case Вы можете использовать if else
// Логические операторы не используются в switch case

var myNumber = 200
switch myNumber {
case 20:
    print("20!")
    if myNumber == 20 {
        print("20 absolutely")
    } else {
        print("Else if")
    }
default:
    break
}

print("=================")
myNumber = 79
switch myNumber {
case 100:
    print("100!")
case 10, 25, 12, 50, 110:
    // Если условие совпадет, хоть в одном значении
    print("10, 25, 12, 50, 110")
case 0...40:
    print("4")
case 41...70:
    print("5")
case 71..<101:
    print("5")
    
default:
    print("N")
}
