import UIKit
import Darwin

var greeting = "Hello, playground"
// Оператор - это символ, который выполняет операцию над операндами
// Операнд - это переменная, константа или значение над которым производится операция

// Арифметические операторы
let x = 10
x + 5
x
x - 5
x
// Если Вы делите целое число на целое число, получаете целое число
x / 3
x
x * 3
x


print("=============")
// % Оператор остатка
10 % 3 // 10 - 3 - 3 - 3 = 1
12 % 4 // 4 + 4 + 4 = 0
156 % 4


print("===========")
// Оператор присваения
var xx = 10
xx = 20

print("============")
// Составной оператор, эти операторы не перезаписывают значение, они его дополняют
var val = 200.0
val += 1
val += 2
val += 2
val = val + 1

val = 20
val -= 10
val *= 2
val /= 3

print("=============")
// HW
// Переконвертировать все типы данных и коллекции
var myString: String = "Abay"
myString = "A"
print(Character("A"))

let myFloat: Float = 0.4444444
print(Double(0.11111111111111111))
print(Double(truncating: true))
print(Bool(truncating: 0))
print(Bool(0.4444444))
print(Bool(0.11111111111111111))
print(Character("2"))
print(Bool(2))


let myInt = 12
print(Int(15))
print(String(10))
// Выучить все операторы

print("Part 2 ============")
print("===================")
// Операторы сравнения
// Используются в условной инструкции  if
// В ответ, всегда Вы будете получать тип данных Bool, true, false

let a = 10
let b = 20

print(a > b) // больше
a < b // меньше

a >= b // больше или равно (одно из 2х значений)
a <= b // Меньше или равно (одно из значений)

a == b // Равно
a != b // Не равно

if a == b {
    print("Code")
} else if a >= b {
    print("A")
} else {
    print("Else")
}

print("==========")
// Изменить значение Bool переменной
// Было true, а стало false
var onOff = false

onOff = true

// Раньше
onOff = !onOff
onOff = !onOff

// Сейчас
onOff.toggle() // переключатель true - false, только есть в Bool
onOff.toggle()
onOff.toggle()
onOff.toggle()

//Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { tmr in
//    print("My time")
//}

print("Унарный оператор==========")
// Унарный оператор или оператор унарного минуса
// -1, -6, -12 ...
var plus = 100
let minus = -plus

// 2 Вариант
let minus2 = -25
let plus2 = (minus2 / minus2) * -minus2

print("Тернарный оператор =============")
// Тернарный условный оператор - состоит из 3х частей
// 1 Выражение
// 2 действие1
// 3 действие2

// выражение ? действие1 : действие2

var isItFriday = true
let age = 25
let name = "Alex!"

// 1
// Если true, то Yes, если false, то No
let today = isItFriday ? "Yes": "No"

// 2
let zero = age != 0 ? "Not zero": "Zero"

// 3
let checkTheName = name == "Alex" ? true:false

print("Логические операторы: &&, ||")
// Часто применяются только в if
// Логический оператор, применяется(используется) при проверке нескольких условий в одной инструкции (от 2х условий)
let x1 = 1
let x2 = 2

if x1 == 10 {
    print("Code")
}

let firstName = "Tom"
var tomAge = 17

print("&& ==")
// && -все условия должны быть true

if firstName == "Tom" && tomAge >= 20 {
    print("Welcome to the club!")
} else {
    print("Oh, sorry")
}

print("|| ======")
// || - минимум одно из условий, должно быть true
if x1 == 20 || x2 > 0 {
    print("Correct ||")
} else {
    print("Else ||")
}

print("and or && ||=============")

if (x1 < 0) || (x2 == 3 && firstName == "Tom") || (10 == 11) || (tomAge >= 20) || (20 <= 20) {
    print("True")
} else {
    print("False")
}

print("Оператор диапазона: ..., ..<=========")
// Операторы диапазона очень часто, применяются в цикле for in и switch case

// ... закрытый диапазон, 1...10 от 1 до 10 включительно
// ..< открытый диапазон, 1..<10 от 1 до 10 (не включительно) до 9

var names = ["Alex", "Tom", "Tim", "Anna", "Gulnar"]
names[1..<names.count]
names[0..<4]


// Выучить операторы
// Поработать с каждым оператором отдельно
// Повторить типы данных и коллекции

var xza = 10
xza = -xza

var isTrue = true
isTrue.toggle()

// ! Если применяете с Bool, то это обратное значение от текущего в Bool
// ! Если Вы используете опционал
print(Int("1")!) // Лучше так не делать, так как если в "" не цифра, точка или другой символ - приложение - будет закрыто
// ?? Оператор, заменяющий nil
print(Int("2") ?? -2)
