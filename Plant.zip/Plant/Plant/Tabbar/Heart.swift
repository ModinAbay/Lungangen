//
//  Heart.swift
//  Plant
//
//  Created by MODIN ABAY on 16.06.2022.
//

import Foundation
import UIKit

class HeartViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
