//
//  HomeCell.swift
//  Plant
//
//  Created by MODIN ABAY on 27.06.2022.
//

import Foundation
import UIKit


struct HomeCollectionViewModel {
    var images: String
    var secondImages: String
}

class HomeCell: UICollectionViewCell {
    
    var image: UIImageView = {
        let img = UIImageView()
        return img
    }()
    
    var seconImage: UIImageView = {
        let simg = UIImageView()
        return simg
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
    }
}

extension HomeCell: ConfigureUI {
    func setupUI() {
        [image, seconImage].forEach {
            contentView.addSubview($0)
        }
        image.snp.makeConstraints {
            $0.center.centerY.equalToSuperview()
        }
        seconImage.snp.makeConstraints {
            $0.top.equalToSuperview().inset(20)
            $0.leading.equalToSuperview().inset(25)
        }
    }
    
    func configureUI() {
    }
    func configure(data: HomeCollectionViewModel) {
        image.image = UIImage(named: data.images)
        image.image = UIImage(named: data.secondImages)
    }

}
