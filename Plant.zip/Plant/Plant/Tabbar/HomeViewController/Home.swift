//
//  HpmeViewController.swift
//  Plant
//
//  Created by MODIN ABAY on 16.06.2022.
//

import Foundation
import UIKit

class HomeViewController: UIViewController {
    
    
    var avatarButton: UIButton = {
        let btn = UIButton()
        btn.layer.cornerRadius = 22
        btn.largeContentImage = UIImage(named: "")
        btn.backgroundColor = UIColor(red: 0.922, green: 0.992, blue: 0.949, alpha: 1)
        return btn
    }()
    
    var shoppingcartButton: UIButton = {
        let btn = UIButton()
        btn.layer.cornerRadius = 22
        btn.largeContentImage = UIImage(named: "")
        btn.backgroundColor = UIColor(red: 0.922, green: 0.992, blue: 0.949, alpha: 1)
        return btn
    }()
    
    var firstLabel: UILabel = {
        let lb = UILabel()
        lb.text = "Let’s find your plants!"
        lb.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        lb.font = lb.font.withSize(28)
        lb.dropShadow()
        return lb
    }()
    
    var searchplantTextfield: UITextField = {
        let tf = UITextField()
        tf.text = "Search plant"
        tf.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        tf.backgroundColor = .white
        tf.layer.borderWidth = 1
        tf.layer.borderColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1).cgColor
        let findTextFieldImageView = UIImageView(frame: CGRect(x: 8.0, y: 12.0, width: 20.0, height: 20.0))
        let image = UIImage(named: "search")
        findTextFieldImageView.image = image
        let findTextFieldView = UIView(frame: CGRect(x: 0, y: 0, width: 38, height: 40))
        findTextFieldView.addSubview(findTextFieldImageView)
        tf.leftViewMode = UITextField.ViewMode.always
        tf.leftView = findTextFieldView
        return tf
    }()
    
    var firstCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        return cv
    }()
    var exploreCollectionView: UICollectionView = {
        let loyaut = UICollectionViewFlowLayout()
        loyaut.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: loyaut)
        return cv
    }()
    
    var watchCollectionView: UICollectionView = {
        let loyaut = UICollectionViewFlowLayout()
        loyaut.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: loyaut)
        return cv
    }()
    
    var ExploreLabel: UILabel = {
        let lb = UILabel()
        lb.text = "Explore"
        lb.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        lb.font = lb.font.withSize(20)
        return lb
    }()
    
    var swapImage: UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "swap")
        return img
    }()
    
    var textLabel: UILabel = {
        let lb = UILabel()
        lb.text = "Watch other Plantita"
        lb.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        lb.font = lb.font.withSize(20)
        return lb
    }()
    
    var seeLabel: UILabel = {
        let lb = UILabel()
        lb.text = "See more >>"
        lb.textColor = UIColor(red: 0.094, green: 0.29, blue: 0.173, alpha: 1)
        lb.font = lb.font.withSize(8)
        return lb
    }()
    
    var recomendLabel: UILabel = {
        let lb = UILabel()
        lb.textColor = .systemGray
        lb.text = "Recommend"
        return lb
    }()
    
    var topLabel: UILabel = {
        let lb = UILabel()
        lb.textColor = .systemGray
        lb.text = "Top"
        return lb
    }()
    
    var indorLabel: UILabel = {
        let lb = UILabel()
        lb.textColor = .systemGray
        lb.text = "Indoor"
        return lb
    }()
    
    var outdoorLabel: UILabel = {
        let lb = UILabel()
        lb.textColor = .systemGray
        lb.text = "Outdoor"
        return lb
    }()
    
    var exoticLabel: UILabel = {
        let lb = UILabel()
        lb.textColor = .systemGray
        lb.text = "Exotic"
        return lb
    }()
    
    lazy var labelSecondStackView: UIStackView = {
        let sv = UIStackView(arrangedSubviews: [
        recomendLabel,
        topLabel,
        indorLabel,
        outdoorLabel,
        exoticLabel
        ])
        sv.spacing = 5
        sv.axis = .horizontal
        return sv
    }()
    
    lazy var labelStackView: UIStackView = {
        let svone = UIStackView(arrangedSubviews: [
            textLabel,
            seeLabel
        ])
        svone.axis = .horizontal
        svone.spacing = 115
        return svone
    }()
    
    var images: [HomeCollectionViewModel] = [
    HomeCollectionViewModel(images: "cactus", secondImages: "cactus"),
    HomeCollectionViewModel(images: "cactus", secondImages: "cactus"),
    HomeCollectionViewModel(images: "cactus", secondImages: "cactus"),
    HomeCollectionViewModel(images: "cactus", secondImages: "cactus")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
}

extension HomeViewController: ConfigureUI {
    func setupUI() {
        [avatarButton, shoppingcartButton, firstCollectionView, exploreCollectionView, watchCollectionView, firstLabel, searchplantTextfield, ExploreLabel, swapImage, labelStackView, labelSecondStackView].forEach {
            view.addSubview($0)
        }
        labelStackView.snp.makeConstraints {
            $0.top.equalTo(exploreCollectionView.safeAreaLayoutGuide.snp.bottom).inset(-19)
            $0.leading.equalToSuperview().inset(32)
        }
        avatarButton.snp.makeConstraints {
            $0.top.equalToSuperview().inset(32)
            $0.leading.equalToSuperview().inset(24)
            $0.height.equalTo(30)
            $0.width.equalTo(29)
        }
        
        shoppingcartButton.snp.makeConstraints {
            $0.top.equalToSuperview().inset(32)
            $0.trailing.equalToSuperview().inset(24)
            $0.height.equalTo(30)
            $0.width.equalTo(29)
        }
        
        firstCollectionView.snp.makeConstraints {
            $0.top.equalToSuperview().inset(214)
            $0.leading.trailing.equalToSuperview().inset(25)
            $0.height.equalTo(196)
            $0.width.equalTo(400)
        }
        
        exploreCollectionView.snp.makeConstraints {
            $0.top.equalToSuperview().inset(453)
            $0.leading.equalToSuperview().inset(25)
            $0.height.equalTo(147)
            $0.width.equalTo(349)
        }
        
        watchCollectionView.snp.makeConstraints {
            $0.top.equalToSuperview().inset(646)
            $0.leading.equalToSuperview().inset(25)
            $0.height.equalTo(90)
            $0.width.equalTo(349)
        }
        
        firstLabel.snp.makeConstraints {
            $0.top.equalTo(avatarButton.safeAreaLayoutGuide.snp.bottom).inset(-20)
            $0.leading.equalToSuperview().inset(25)
        }
        
        searchplantTextfield.snp.makeConstraints {
            $0.top.equalTo(firstLabel.safeAreaLayoutGuide.snp.bottom).inset(-30)
            $0.leading.equalToSuperview().inset(25)
            $0.width.equalTo(325)
            $0.height.equalTo(35)
        }
        
        ExploreLabel.snp.makeConstraints {
            $0.top.equalTo(firstCollectionView.safeAreaLayoutGuide.snp.bottom).inset(-13)
            $0.leading.equalToSuperview().inset(37)
        }
        
        swapImage.snp.makeConstraints {
            $0.top.equalTo(firstCollectionView.safeAreaLayoutGuide.snp.bottom).inset(-13)
            $0.trailing.equalToSuperview().inset(25)
        }
        labelSecondStackView.snp.makeConstraints {
            $0.top.equalTo(searchplantTextfield.safeAreaLayoutGuide.snp.bottom).inset(-4)
            $0.leading.trailing.equalToSuperview().inset(25)
        }
        
        firstCollectionView.delegate = self
        firstCollectionView.dataSource = self
        firstCollectionView.register(HomeCell.self, forCellWithReuseIdentifier: "HomeCellID")
        exploreCollectionView.delegate = self
        exploreCollectionView.dataSource = self
        exploreCollectionView.register(HomeCell.self, forCellWithReuseIdentifier: "HomeSeconCellID")
        watchCollectionView.delegate = self
        watchCollectionView.dataSource = self
        watchCollectionView.register(HomeCell.self, forCellWithReuseIdentifier: "HomeThirdCellID")
    }
    
    func configureUI() {
    }
}

extension HomeViewController: UICollectionViewDelegateFlowLayout, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 4
            }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = firstCollectionView.dequeueReusableCell(withReuseIdentifier: "HomeCellID", for: indexPath) as! HomeCell
        cell.layer.cornerRadius = 20
        cell.configure(data: images[indexPath.row])
        
        if (collectionView == exploreCollectionView) {
        let cell = exploreCollectionView.dequeueReusableCell(withReuseIdentifier: "HomeSeconCellID", for: indexPath) as! HomeCell
            cell.backgroundColor = .systemGreen
            cell.layer.cornerRadius = 20
            return cell
    }
        
        if (collectionView == watchCollectionView) {
            let cell = watchCollectionView.dequeueReusableCell(withReuseIdentifier: "HomeThirdCellID", for: indexPath) as! HomeCell
            cell.backgroundColor = .systemGreen
            cell.layer.cornerRadius = 20
            return cell
        }
        
        return cell
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
            return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if collectionView == firstCollectionView {
            return CGSize(width: 125, height: 165)
        }else if collectionView == exploreCollectionView {
            return CGSize(width: 96, height: 104)
        }else{
            return CGSize(width: 134, height: 94)
        }
    }
}
