import UIKit

// Цикл - нужен для повторения неких действий ограниченное или не ограниченное количество раз
// Есть 3 цикла

// 1 for in - используется чаще всего
// Этот цикл - являет диапазоном, всегда знает откуда начать действие и чем закончить

// 2 while - цикл условие, всегда знает, откуда начнется. но не знает, когда закончится
// Этот цикл, иожет никогда не завершится

// 3 repeat while - аналогично циклу while, но этот цикл - выполнится минимум один раз


print("FOR IN ===============")
// Как записать for in
// 1 for ключевое слово
// 2 константа, у этой константы не должен быть указан тип, а так же - значение
// 3 in ключевое слово
// 4 диапазон, строка или любая коллекция
// 5 {
// 6 код, который выполняется в for in
// 7 }


// Если Вы хотите пройти по числам

// Если это действие не меняется, то используйте - цикл
print("Hello")
print("Hello")
print("Hello")

print("=========")
// название переменной между for in может быть - любое, переменная или константа ОБЯЗАТЕЛЬНО должна быть
for i in 1...3 {
    print("Hi")
}

print("==========")
// Если переменная, между for in не прочитана в цикле, ее множно заменить на _
for _ in 1...3 {
    print("Have a nice day")
}

print("=========")
for step in 1...5 {
    print("Step number", step)
    // С каждым проходом по циклу, константа будет меняться - изменять значение
}

var goodStudents = 15
var students = 20
print("============")
// Первое значение в диапазоне ВСЕГДА должно быть меньше, чем второе!
for abay in goodStudents...students {
    print("Razdat", abay)
}





//HomeWork
var button = UIButton()
for button in 1...3 {
    print("Button")
}

var botle = 25
var botleForDrivers = 4

for _ in botleForDrivers..<botle {
    print("botle")
}

var allPlayersNumber = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]
var startPlayersNumber = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]

for rezervFootballPlayers in 0...11 {
    print("rezerv")
}

var names = ["John", "Messi", "Neymar", "Jordi", "John", "Messi", "Neymar", "Jordi", "John", "Messi", "Neymar", "Jordi","John", "Messi", "Neymar", "Jordi"]

for hello in 7...14 {
    print("Hello everybody")
}

print("Part 2 =====================")
print("============================")

let wordsOf1 = "Hello, Lolly, how are you?"

for probely in wordsOf1 {
    print(probely)
}

for findSpace in wordsOf1 {
    if findSpace == " " {
        print("space was found")
    }
}

var findSpaces = 0
for x in wordsOf1 {
    if x == " " {
        print("Found")
        findSpaces += 1
    }
}

print(findSpaces)

print("MiniTasks =======")
// Создать переменную - записать в нее строку
// Найти все буквы а внутри строки и посчитать - сколько их

var name = "Abay"

for findA in name {
    print(findA)
    if findA == "a" {
        print("FindA")
    }
}

for findBigA in name {
    print(findBigA)
    if findBigA == "A" {
        print("FindBigA")
    }
       
}


print("=============")
for i in name {
    if i.lowercased() == "a".lowercased() {
        print("A or a", i)
    }
}

for i in name {
    if i == "A" {
        print("Big A")
    }
    
    if i == "a" {
        print("Small a")
    }
}


print("===============")
var counterAa = 0

for i in name {
    if i.lowercased() == "a".lowercased() {
        counterAa += 1
    }
}

print("A count =", counterAa)

print("=============")
let words2 = "Hello, my name is Alex and Marty with Melony and Me"

var schitatBukvy = 0

for i in words2 {
    if i.lowercased() == " " {
        print("How is spacer")
        schitatBukvy += 1
    }
}

print("Bukvy", schitatBukvy)

var bukva = 0
for i in words2 {
    if i.lowercased() == "e".lowercased() {
        bukva += 1
    }
}

print("All", bukva)

print("===============")
// Вывести в цикле - все буквы - кроме "a", "e"
// let words2 = "Hello, my name is Alex and Marty with Melony and Me"

for q in words2 {
    if q != "a" && q != "e" {
        print(q)
    }
}

print("===========")
// Создать константу и записать в нее фразу
// В цикле, отобразить все буквы, кроме "a", "b", "e", "i"

let phrase = "Life is good and be crazy"

for a in phrase {
    if a != "a" && a != "b" && a != "e" && a != "i" {
        print(a)
    }
}

// когда считаем сумму или все товары больше 10
// чтобы повторять неограниченное кол-во раз

print("=========")
// Получить все цифры из строки
let phoneN = "My phone number is 1(123)-567-4589"

for n in phoneN {
    if n.isNumber {
        print("Number", n)
    }
}

print("============")

for n in phoneN {
    if n.isLetter {
        print("Symbol", n)
    }
}


print("===========")
let abb = "Alex, Tom, Piter, Oli, Max, Aly, Tomas, Tim"

for upp in abb {
    if upp.isUppercase {
        print("Upper", upp)
    }
}


print("=================")
// HW
// Повторить if else
// Повторить все операторы
// На каждый пример - в этом файле - сделать 2 Ваших примера

